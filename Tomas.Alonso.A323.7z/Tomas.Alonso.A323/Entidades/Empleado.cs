﻿namespace Entidades
{
    public abstract class Empleado
    {
        protected TimeSpan horaEgreso;
        protected TimeSpan horaIngreso;
        protected string legajo;
        protected string nombre;

        protected Empleado(string legajo, string nombre, TimeSpan horaIngreso)
        {
            this.horaIngreso = horaIngreso;
            this.legajo = legajo;
            this.nombre = nombre;
        }

        public TimeSpan HoraEgreso
        {
            get { return horaEgreso; }
            set { horaEgreso = ValidaHoraEgreso(value); }
        }

        public TimeSpan HoraIngreso
        {
            get { return horaIngreso; }
        }

        public string Legajo
        {
            get { return legajo; }
        }

        public string Nombre
        {
            get { return nombre; }
        }

        public abstract string EmitirFactura();

        protected double Facturar()
        {
            TimeSpan tiempoTrabajado=horaEgreso-horaIngreso;
            return tiempoTrabajado.TotalHours;
        }

        private TimeSpan ValidaHoraEgreso(TimeSpan horaEgreso)
        {
            if(horaEgreso > horaIngreso)
            {
                return horaEgreso;
            }
            else
            {
                return DateTime.Now.TimeOfDay;
            }
        }

        public static bool operator !=(Empleado emp1, Empleado emp2)
        {
            return !(emp1 == emp2);
        }

        public static bool operator ==(Empleado emp1, Empleado emp2)
        {
            if (ReferenceEquals(emp1, emp2))
            {
                return true;
            }
            if (ReferenceEquals(emp1, null) || ReferenceEquals(emp2, null))
            {
                return false;
            }
            return emp1.legajo == emp2.legajo;
        }

        public override bool Equals(object obj)
        {
            if (obj is Empleado)
            {
                Empleado other = (Empleado)obj;
                return this == other;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return legajo.GetHashCode();
        }
    }
}
