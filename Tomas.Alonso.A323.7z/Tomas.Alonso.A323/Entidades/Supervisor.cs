﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Supervisor:Empleado
    {
        private static float valorHora=1025.50F;

        private Supervisor(string legajo): base( legajo, "n/a", new TimeSpan(9, 0, 0))
        {
        }

        public Supervisor(string legajo, string nombre, TimeSpan horaIngreso): base(legajo, nombre, horaIngreso)
        {
        }
    
        public static float ValorHora
        {
            get { return valorHora; }
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }

        public override string EmitirFactura()
        {
            double totalHorasTrabajadas = Facturar();
            float importe = (float)totalHorasTrabajadas * valorHora;
            return $"Factura de: {ToString()}\nImporte a facturar: {importe}";
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {legajo} - {nombre}";
        }

        protected new double Facturar()
        {
            TimeSpan tiempoTrabajado = horaEgreso - horaIngreso;
            return tiempoTrabajado.TotalHours * valorHora;
        }

        public static implicit operator Supervisor(string legajo)
        {
            return new Supervisor(legajo);
        }
    }
}
