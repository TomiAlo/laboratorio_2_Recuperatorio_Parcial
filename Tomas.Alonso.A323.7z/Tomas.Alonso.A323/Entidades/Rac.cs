﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Rac:Empleado
    {
        public enum EGrupo
        {
            CALL_IN,
            CALL_OUT,
            RRSS
        }

        private static float valorHora = 875.90F;
        private EGrupo grupo;

        public Rac(string legajo, string nombre, TimeSpan horaIngreso) : base(legajo, nombre, horaIngreso)
        {
            this.legajo = legajo;
            this.nombre = nombre;
            this.horaIngreso = horaIngreso;
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso ,EGrupo grupo = EGrupo.CALL_IN): base(legajo, nombre, horaIngreso)
        {
            this.grupo = grupo;
        }

        public EGrupo Grupo
        { get { return grupo; }       
        }

        public static float ValorHora
        {
            get { return valorHora; }
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }

        private double CalculaBonoDeGrupo()
        {
            switch (grupo)
            {
                case EGrupo.CALL_OUT:
                    return 0.1;
                case EGrupo.RRSS:
                    return 0.2;
                default:
                    return 0.0;
            }
        }

        public override string EmitirFactura()
        {
            double totalHorasTrabajadas = Facturar();
            float importe = (float)totalHorasTrabajadas * valorHora;
            return $"Factura de: {ToString()}\nImporte a facturar: {importe}";
        }

        protected new double Facturar()
        {
            TimeSpan tiempoTrabajado = horaEgreso - horaIngreso;
            double bono = CalculaBonoDeGrupo();
            return tiempoTrabajado.TotalHours * valorHora * (1 + bono);
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {grupo} - {legajo} - {nombre}";
        }
    }
}
